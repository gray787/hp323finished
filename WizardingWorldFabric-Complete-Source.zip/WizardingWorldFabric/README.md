# Wizarding World Fabric Mod (Minecraft 26.3)

## Build

This is a Fabric mod source project targeting Minecraft Java 26.3 and Java 25. It includes a GitHub Actions workflow at `.github/workflows/build.yml`.

1. Upload the contents of this folder to the root of a GitHub repository.
2. Open **Actions** and run **Build Wizarding World Mod** (or push a commit).
3. Download the `WizardingWorldFabric-JAR` artifact from a successful run.
4. Put the compiled `.jar` in `.minecraft/mods` alongside Fabric API for Minecraft 26.3.

## Included gameplay systems

- 50 wand items (49 wood/core combinations plus the Elder Wand), wand casting and a visible particle tracer.
- A spellbook GUI opened with **Z**, containing 2,000 catalog entries with descriptions and page navigation. Selecting an entry sends the selection to the server; cast with a wand. The Elder Wand bypasses spell learning.
- Spell effects are implemented as a set of reusable gameplay effects. The 2,000 entries map onto this smaller set of effect implementations; they are not 2,000 individually unique spell mechanics. Unknown effect labels map to a generic reveal/glow effect.
- 200 registered ingredient items and 100 registered potion items. Potion items currently apply a shared restorative effect; this is not a full ingredient-aware brewing recipe system.
- Four named brooms (Cleansweep 11, Nimbus 2000, Firebolt, Comet 260) that enable flight.
- Wizarding currency items and Quidditch ball items.
- `/harrypotter hogwarts`, `/harrypotter 9 3/4`, `/harrypotter dursleys`, `/harrypotter quidditch world cup`, `/harrypotter elderwand`, `/harrypotter spells`, `/harrypotter spell <1-2000>`.
- Give items with `/harrypotter wand <1-50>`, `/harrypotter ingredient <1-200>`, `/harrypotter potion <1-100>`, and `/harrypotter brooms`; place a cauldron with `/harrypotter cauldron`.
- The Hogwarts command builds a compact block-built grounds set, not a full-scale faithful castle. Platform, Dursleys and World Cup commands build compact structures at the player's position. Choose a clear area and back up worlds before testing large builds.

## Known limitations

This project has been expanded from a prototype, but I cannot certify a successful 26.3 build in this environment because Gradle/Minecraft dependencies are not installed here. GitHub Actions is configured to compile and verify the output JAR. If the workflow fails, its build log is needed for a version-specific fix. The spell catalog includes generated placeholder entries beyond the named spells; many effects share implementations. Potion brewing, full Quidditch gameplay, custom textures/models, and detailed landmark builds remain future work.
